require("dotenv").config();
const express=require("express");
const db=require("../../src/database/db"); db.init();
const app=express(); app.use(express.json());
app.get("/api/health",(req,res)=>res.json({ok:true,name:"MrWarriorBOT"}));
app.get("/api/guild/:id/config",(req,res)=>res.json(db.guild(req.params.id)));
app.listen(process.env.DASHBOARD_PORT||3000,()=>console.log("Dashboard API listening."));
