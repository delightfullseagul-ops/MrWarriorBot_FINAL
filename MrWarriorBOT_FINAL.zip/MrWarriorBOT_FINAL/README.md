# MrWarriorBOT — Final Build

## Setup
1. Install Node.js 20+.
2. Upload this folder to your VPS.
3. Edit `.env` and set `DISCORD_TOKEN`, `CLIENT_ID`, and `OWNER_ID`.
4. In the Discord Developer Portal enable:
   - Server Members Intent
   - Message Content Intent
5. Run:
```bash
npm install
npm run sync
npm start
```

For 24/7 operation:
```bash
npm install -g pm2
pm2 start index.js --name MrWarriorBOT
pm2 save
pm2 startup
```

## Security
Never publish `.env`. The included `.env` contains placeholders only. Never send a bot token in chat.

## Major systems
Moderation, Anti-Nuke + Extra Owners/Whitelist, automatic/manual backups, AutoMod, tickets, giveaways, verification, applications, multi-channel welcome/leave/boost messages, embed templates, custom emoji aliases, snipe/edit-snipe, reaction roles, suggestions, starboard, polls, utility/fun commands, logging foundation, owner controls, and per-guild JSON configuration.

## Multi-channel messages
Welcome, leave and boost systems store multiple independent channel/message entries per guild. Each can be enabled/disabled independently and supports `{user}`, `{username}`, `{server}`, `{memberCount}`, and `{channel}` placeholders.

## Backup format
`.mwb` files are JSON snapshots with a version, guild metadata, role data, channel data and permission-overwrite data. Validate imported files before using them.