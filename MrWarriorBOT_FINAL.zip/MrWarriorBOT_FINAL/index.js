require("dotenv").config();
const { Client, GatewayIntentBits, Partials, Collection } = require("discord.js");
const { loadCommands } = require("./src/handlers/commandHandler");
const { loadEvents } = require("./src/handlers/eventHandler");
const db = require("./src/database/db");

if (!process.env.DISCORD_TOKEN || process.env.DISCORD_TOKEN === "PASTE_YOUR_BOT_TOKEN_HERE") {
  console.error("DISCORD_TOKEN is missing. Put it in .env before starting.");
  process.exit(1);
}

db.init();
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildPresences
  ],
  partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction]
});

client.commands = new Collection();
loadCommands(client);
loadEvents(client);

client.login(process.env.DISCORD_TOKEN);
