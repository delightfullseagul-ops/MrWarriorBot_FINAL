const { PermissionFlagsBits } = require("discord.js");
function ownerOnly(interaction) {
  return interaction.user.id === interaction.guild?.ownerId || interaction.user.id === process.env.OWNER_ID;
}
function canManage(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) || ownerOnly(interaction);
}
module.exports={ownerOnly,canManage};
