function render(text, ctx={}) {
  return String(text || "")
    .replaceAll("{user}", ctx.user || "")
    .replaceAll("{username}", ctx.username || "")
    .replaceAll("{server}", ctx.server || "")
    .replaceAll("{memberCount}", String(ctx.memberCount ?? ""))
    .replaceAll("{channel}", ctx.channel || "");
}
module.exports={render};
