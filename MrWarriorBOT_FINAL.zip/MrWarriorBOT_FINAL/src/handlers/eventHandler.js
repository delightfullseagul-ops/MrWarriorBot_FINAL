const fs=require("fs"),path=require("path");
function loadEvents(client){
  const dir=path.join(__dirname,"..","events");
  for(const f of fs.readdirSync(dir)){
    if(!f.endsWith(".js"))continue;
    const e=require(path.join(dir,f));
    if(e.once)client.once(e.name,(...a)=>e.execute(client,...a));
    else client.on(e.name,(...a)=>e.execute(client,...a));
  }
}
module.exports={loadEvents};
