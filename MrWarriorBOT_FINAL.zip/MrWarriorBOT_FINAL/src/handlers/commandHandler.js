const fs=require("fs"),path=require("path");
function loadCommands(client){
  const base=path.join(__dirname,"..","commands");
  function walk(dir){
    for(const x of fs.readdirSync(dir,{withFileTypes:true})){
      const p=path.join(dir,x.name);
      if(x.isDirectory())walk(p);
      else if(x.name.endsWith(".js")){
        try{const c=require(p);if(c.data?.name){client.commands.set(c.data.name,c);}}catch(e){console.error("Command load:",p,e.message);}
      }
    }
  }
  walk(base);
}
module.exports={loadCommands};
