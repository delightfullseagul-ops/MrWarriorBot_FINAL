const db=require("../database/db");
function push(guildId,type,item,max=10){
  db.update(guildId,g=>{
    const a=g.snipes[type];
    a.unshift(item);
    g.snipes[type]=a.slice(0,max);
  });
}
function get(guildId,type,n=1){return db.guild(guildId).snipes[type][n-1]||null;}
module.exports={push,get};
