const {EmbedBuilder}=require("discord.js");
const {render}=require("../utils/format");
function buildEntry(entry,ctx){
  const content=render(entry.message||"",ctx);
  const out={content:entry.useContent===false?undefined:content};
  if(entry.embed){
    const e=new EmbedBuilder();
    if(entry.embed.title)e.setTitle(render(entry.embed.title,ctx));
    if(entry.embed.description)e.setDescription(render(entry.embed.description,ctx));
    if(entry.embed.color)e.setColor(entry.embed.color);
    if(entry.embed.image)e.setImage(entry.embed.image);
    if(entry.embed.thumbnail)e.setThumbnail(entry.embed.thumbnail);
    if(entry.embed.footer)e.setFooter({text:render(entry.embed.footer,ctx)});
    if(entry.embed.timestamp)e.setTimestamp();
    out.embeds=[e];
  }
  return out;
}
module.exports={buildEntry};
