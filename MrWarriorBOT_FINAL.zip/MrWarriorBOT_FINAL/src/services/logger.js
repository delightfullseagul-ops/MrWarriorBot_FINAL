const db=require("../database/db");
const {EmbedBuilder}=require("discord.js");
async function log(guild,event,title,description) {
  const g=db.guild(guild.id);
  if(!g.logging.enabled || !g.logging.channelId) return;
  const ch=guild.channels.cache.get(g.logging.channelId);
  if(!ch?.isTextBased()) return;
  const e=new EmbedBuilder().setTitle(title).setDescription(description||"").setTimestamp();
  try{ await ch.send({embeds:[e]}); }catch{}
}
module.exports={log};
