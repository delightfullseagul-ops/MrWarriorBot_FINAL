function resolve(text,map={}) {
  return String(text||"").replace(/:([A-Za-z0-9_+-]+):/g,(m,n)=>map[n]||m);
}
module.exports={resolve};
