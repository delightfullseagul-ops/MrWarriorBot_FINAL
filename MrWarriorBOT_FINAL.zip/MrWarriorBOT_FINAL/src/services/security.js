const db=require("../database/db");
const {PermissionFlagsBits}=require("discord.js");

function trusted(guild,userId){
  const g=db.guild(guild.id);
  return userId===guild.ownerId || userId===process.env.OWNER_ID || g.antinuke.extraOwners.includes(userId) || g.antinuke.whitelist.includes(userId);
}
function threshold(guild,type){
  const g=db.guild(guild.id);
  return g.antinuke.thresholds[type] || 3;
}
async function lockdown(guild){
  const g=db.guild(guild.id);
  g.antinuke.lockdown=true; db.save();
  for(const ch of guild.channels.cache.values()){
    if(!ch.isTextBased() || !ch.permissionOverwrites) continue;
    try{ await ch.permissionOverwrites.edit(guild.roles.everyone,{SendMessages:false}); }catch{}
  }
}
module.exports={trusted,threshold,lockdown};
