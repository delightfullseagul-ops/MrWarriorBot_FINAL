const fs=require("fs"), path=require("path");
const db=require("../database/db");
function snapshot(guild,name="automatic"){
  const roles=[...guild.roles.cache.values()].filter(r=>r.id!==guild.id).map(r=>({id:r.id,name:r.name,color:r.hexColor,hoist:r.hoist,mentionable:r.mentionable,position:r.position,permissions:r.permissions.bitfield.toString()}));
  const channels=[...guild.channels.cache.values()].map(c=>({id:c.id,name:c.name,type:c.type,position:c.rawPosition,parentId:c.parentId,topic:c.topic||null,nsfw:!!c.nsfw,rateLimitPerUser:c.rateLimitPerUser||0,permissionOverwrites:c.permissionOverwrites.cache.map(o=>({id:o.id,type:o.type,allow:o.allow.bitfield.toString(),deny:o.deny.bitfield.toString()}))}));
  return {version:1,name,guildId:guild.id,guildName:guild.name,createdAt:new Date().toISOString(),roles,channels};
}
function saveSnapshot(guild,name="automatic"){
  const snap=snapshot(guild,name), dir=path.resolve("./data/backups",guild.id);
  fs.mkdirSync(dir,{recursive:true});
  const idx=String((db.guild(guild.id).backups.items.length||0)+1).padStart(3,"0");
  const file=path.join(dir,`backup-${idx}.mwb`);
  fs.writeFileSync(file,JSON.stringify(snap,null,2));
  db.update(guild.id,g=>{g.backups.latest=file;g.backups.items.push({id:`backup-${idx}`,name,file,createdAt:snap.createdAt});});
  return {snap,file,id:`backup-${idx}`};
}
function readBackup(file){return JSON.parse(fs.readFileSync(file,"utf8"));}
module.exports={snapshot,saveSnapshot,readBackup};
