const db=require("../database/db"),{buildEntry}=require("../services/messages");
module.exports={name:"guildMemberRemove",async execute(client,m){
 const g=db.guild(m.guild.id);if(!g.leave.enabled)return;
 const ctx={user:m.user?`<@${m.id}>`:m.id,username:m.user?.username||m.user?.tag||"Member",server:m.guild.name,memberCount:m.guild.memberCount};
 for(const e of g.leave.entries.filter(x=>x.enabled)){const ch=m.guild.channels.cache.get(e.channelId);if(ch?.isTextBased())try{await ch.send(buildEntry(e,ctx));}catch{}}
}};