const db=require("../database/db"),{buildEntry}=require("../services/messages");
module.exports={name:"guildMemberUpdate",async execute(client,oldM,newM){
 if(!newM.guild||oldM.premiumSince||!newM.premiumSince)return;
 const g=db.guild(newM.guild.id);if(!g.boost.enabled)return;
 const ctx={user:`<@${newM.id}>`,username:newM.user.username,server:newM.guild.name,memberCount:newM.guild.memberCount};
 for(const e of g.boost.entries.filter(x=>x.enabled)){const ch=newM.guild.channels.cache.get(e.channelId);if(ch?.isTextBased())try{await ch.send(buildEntry(e,ctx));}catch{}}
}};