const {push}=require("../services/snipe");
module.exports={name:"messageDelete",async execute(client,m){
  if(!m.guild||m.author?.bot)return;
  push(m.guild.id,"messages",{author:m.author?.tag||"Unknown",userId:m.author?.id,content:m.content||"",channelId:m.channelId,messageId:m.id,deletedAt:new Date().toISOString(),attachments:[...m.attachments.values()].map(a=>a.url)});
}};