const {Collection}=require("discord.js");
module.exports={name:"interactionCreate",once:false,async execute(client,i){
  if(!i.isChatInputCommand()) return;
  const c=client.commands.get(i.commandName); if(!c)return;
  try{await c.execute(i,client);}catch(e){console.error(e);if(!i.replied&&!i.deferred)await i.reply({content:"❌ An error occurred.",ephemeral:true});}
}};