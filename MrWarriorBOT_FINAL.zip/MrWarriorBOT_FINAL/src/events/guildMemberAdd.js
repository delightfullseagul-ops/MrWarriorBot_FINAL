const db=require("../database/db"),{buildEntry}=require("../services/messages");
module.exports={name:"guildMemberAdd",async execute(client,m){
 const g=db.guild(m.guild.id); if(!g.welcome.enabled)return;
 const ctx={user:`<@${m.id}>`,username:m.user.username,server:m.guild.name,memberCount:m.guild.memberCount};
 for(const e of g.welcome.entries.filter(x=>x.enabled)){const ch=m.guild.channels.cache.get(e.channelId);if(ch?.isTextBased())try{await ch.send(buildEntry(e,ctx));}catch{}}
 if(g.verification.enabled&&g.verification.roleId){try{await m.roles.add(g.verification.roleId);}catch{}}
}};