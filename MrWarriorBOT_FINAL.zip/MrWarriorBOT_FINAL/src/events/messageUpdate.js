const {push}=require("../services/snipe");
module.exports={name:"messageUpdate",async execute(client,oldM,newM){
  if(!newM.guild||newM.author?.bot||oldM.content===newM.content)return;
  push(newM.guild.id,"edits",{author:newM.author?.tag,channelId:newM.channelId,messageId:newM.id,before:oldM.content||"",after:newM.content||"",editedAt:new Date().toISOString()});
}};