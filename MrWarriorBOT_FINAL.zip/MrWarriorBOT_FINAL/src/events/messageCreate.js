const db=require("../database/db");
const {push}=require("../services/snipe");
const timers=new Map();
module.exports={name:"messageCreate",async execute(client,m){
  if(!m.guild||m.author.bot)return;
  const g=db.guild(m.guild.id), a=g.automod;
  if(a.enabled&&a.spam.enabled){
    const key=m.guild.id+":"+m.author.id, now=Date.now(), arr=(timers.get(key)||[]).filter(x=>now-x<a.spam.windowMs);
    arr.push(now);timers.set(key,arr);
    if(arr.length>a.spam.max){try{await m.delete();}catch{} return;}
  }
  if(a.enabled&&a.links&&/(https?:\/\/|www\.)/i.test(m.content)){try{await m.delete();}catch{}return;}
  if(a.enabled&&a.invites&&/(discord\.gg\/|discord\.com\/invite\/)/i.test(m.content)){try{await m.delete();}catch{}return;}
  if(a.enabled&&a.badWords.some(w=>m.content.toLowerCase().includes(w.toLowerCase()))){try{await m.delete();}catch{}}
}};