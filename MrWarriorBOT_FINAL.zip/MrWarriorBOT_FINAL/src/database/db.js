const fs = require("fs");
const path = require("path");
const file = path.resolve(process.env.DATABASE_FILE || "./data/database.json");
let data = {};

function init() {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  if (fs.existsSync(file)) {
    try { data = JSON.parse(fs.readFileSync(file, "utf8")); } catch { data = {}; }
  }
  save();
}
function save() { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }
function guild(id) {
  if (!data[id]) data[id] = defaultGuild();
  return data[id];
}
function defaultGuild() {
  return {
    antinuke:{enabled:false, level:"HIGH", extraOwners:[], whitelist:[], thresholds:{ban:3,kick:3,roleDelete:3,channelDelete:3,roleCreate:5,channelCreate:5,webhook:3}, lockdown:false},
    automod:{enabled:false, spam:{enabled:true,max:5,windowMs:5000}, links:false, invites:false, badWords:[], caps:false, duplicate:false, mentionSpam:true, attachments:false},
    logging:{enabled:false, channelId:null, events:{}},
    welcome:{enabled:false, entries:[]},
    leave:{enabled:false, entries:[]},
    boost:{enabled:false, entries:[]},
    tickets:{enabled:false, panels:[], staffRoleIds:[]},
    giveaways:{},
    verification:{enabled:false, roleId:null, channelId:null},
    applications:{panels:[]},
    suggestions:{enabled:false, channelId:null},
    roles:{panels:[]},
    starboard:{enabled:false, channelId:null, threshold:3},
    embeds:{},
    emojis:{},
    snipes:{messages:[],edits:[]},
    backups:{latest:null, items:[]},
    customCommands:{},
    polls:{}
  };
}
function update(id, fn) { const g=guild(id); fn(g); save(); return g; }
function all() { return data; }
module.exports={init,guild,update,save,all,defaultGuild};
