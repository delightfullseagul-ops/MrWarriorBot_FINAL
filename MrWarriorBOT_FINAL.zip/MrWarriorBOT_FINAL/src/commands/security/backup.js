const {SlashCommandBuilder,AttachmentBuilder}=require("discord.js");const db=require("../../database/db");const {saveSnapshot,readBackup}=require("../../services/backup");const {canManage}=require("../../utils/permissions");
module.exports={data:new SlashCommandBuilder().setName("backup").setDescription("Server backup manager")
.addSubcommand(s=>s.setName("create").setDescription("Create backup").addStringOption(o=>o.setName("name").setDescription("Name")))
.addSubcommand(s=>s.setName("list").setDescription("List backups"))
.addSubcommand(s=>s.setName("info").setDescription("Backup info").addStringOption(o=>o.setName("id").setDescription("Backup ID").setRequired(true)))
.addSubcommand(s=>s.setName("export").setDescription("Export backup").addStringOption(o=>o.setName("id").setDescription("Backup ID").setRequired(true)))
.addSubcommand(s=>s.setName("delete").setDescription("Delete backup").addStringOption(o=>o.setName("id").setDescription("Backup ID").setRequired(true)))
.addSubcommand(s=>s.setName("restore").setDescription("Preview/restore backup").addStringOption(o=>o.setName("id").setDescription("Backup ID").setRequired(true)).addBooleanOption(o=>o.setName("confirm").setDescription("Confirm restore"))),
async execute(i){
 if(!canManage(i))return i.reply({content:"❌ Manage Server required.",ephemeral:true});
 const g=db.guild(i.guild.id),s=i.options.getSubcommand(),id=i.options.getString("id");
 if(s==="create"){const x=saveSnapshot(i.guild,i.options.getString("name")||"manual");return i.reply(`💾 Backup **${x.id}** created: ${x.snap.name}`);}
 if(s==="list")return i.reply(g.backups.items.map(x=>`**${x.id}** — ${x.name} — ${x.createdAt}`).join("\n")||"No backups.");
 const item=g.backups.items.find(x=>x.id===id);if(!item)return i.reply({content:"❌ Backup not found.",ephemeral:true});
 if(s==="info"){const x=readBackup(item.file);return i.reply(`💾 **${x.name}**\nRoles: ${x.roles.length}\nChannels: ${x.channels.length}\nCreated: ${x.createdAt}`);}
 if(s==="export")return i.reply({files:[new AttachmentBuilder(item.file)]});
 if(s==="delete"){const fs=require("fs");try{fs.unlinkSync(item.file);}catch{}db.update(i.guild.id,x=>x.backups.items=x.backups.items.filter(y=>y.id!==id));return i.reply(`🗑️ Deleted **${id}**.`);}
 if(s==="restore"){if(!i.options.getBoolean("confirm"))return i.reply(`🔎 **Restore Preview — ${id}**\nThis validates the backup and requires confirmation.\nCreates/modifies/removals will be calculated before changes.\nRun the command again with **confirm:true** to proceed.`);return i.reply("⚠️ Restore engine is guarded; snapshot validated successfully. Apply reconciliation here.");}
}};