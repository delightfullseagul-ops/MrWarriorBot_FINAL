const {SlashCommandBuilder}=require("discord.js");const db=require("../../database/db");const {canManage}=require("../../utils/permissions");
module.exports={data:new SlashCommandBuilder().setName("antinuke").setDescription("Anti-nuke security")
.addSubcommand(s=>s.setName("status").setDescription("Show status"))
.addSubcommand(s=>s.setName("enable").setDescription("Enable"))
.addSubcommand(s=>s.setName("disable").setDescription("Disable"))
.addSubcommand(s=>s.setName("level").setDescription("Set protection level").addStringOption(o=>o.setName("level").setDescription("Level").setRequired(true).addChoices({name:"LOW",value:"LOW"},{name:"MEDIUM",value:"MEDIUM"},{name:"HIGH",value:"HIGH"})))
.addSubcommand(s=>s.setName("extraowner-add").setDescription("Add trusted extra owner").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)))
.addSubcommand(s=>s.setName("extraowner-remove").setDescription("Remove extra owner").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)))
.addSubcommand(s=>s.setName("extraowner-list").setDescription("List extra owners"))
.addSubcommand(s=>s.setName("whitelist-add").setDescription("Whitelist user").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)))
.addSubcommand(s=>s.setName("whitelist-remove").setDescription("Remove whitelist").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true))),
async execute(i){
 if(!canManage(i))return i.reply({content:"❌ Manage Server required.",ephemeral:true});
 const g=db.guild(i.guild.id),s=i.options.getSubcommand(),u=i.options.getUser("user");
 if(s==="status")return i.reply(`🛡️ Anti-Nuke: **${g.antinuke.enabled?"ON":"OFF"}**\nLevel: **${g.antinuke.level}**\nExtra Owners: **${g.antinuke.extraOwners.length}**\nWhitelist: **${g.antinuke.whitelist.length}**`);
 if(s==="enable"){g.antinuke.enabled=true;db.save();return i.reply("🛡️ Anti-Nuke enabled.");}
 if(s==="disable"){g.antinuke.enabled=false;db.save();return i.reply("🛡️ Anti-Nuke disabled.");}
 if(s==="level"){g.antinuke.level=i.options.getString("level");db.save();return i.reply(`🛡️ Protection level: **${g.antinuke.level}**`);}
 if(s==="extraowner-add"){if(!g.antinuke.extraOwners.includes(u.id))g.antinuke.extraOwners.push(u.id);db.save();return i.reply(`👑 Added ${u} as an Extra Owner.`);}
 if(s==="extraowner-remove"){g.antinuke.extraOwners=g.antinuke.extraOwners.filter(x=>x!==u.id);db.save();return i.reply(`👑 Removed ${u} from Extra Owners.`);}
 if(s==="extraowner-list")return i.reply(`👑 Extra Owners:\n${g.antinuke.extraOwners.map(x=>`<@${x}>`).join("\n")||"None"}`);
 if(s==="whitelist-add"){if(!g.antinuke.whitelist.includes(u.id))g.antinuke.whitelist.push(u.id);db.save();return i.reply(`✅ Whitelisted ${u}.`);}
 if(s==="whitelist-remove"){g.antinuke.whitelist=g.antinuke.whitelist.filter(x=>x!==u.id);db.save();return i.reply(`✅ Removed ${u} from whitelist.`);}
}};