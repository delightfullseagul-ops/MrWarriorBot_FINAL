const {SlashCommandBuilder,EmbedBuilder}=require("discord.js");const db=require("../../database/db");const {canManage}=require("../../utils/permissions");
module.exports={data:new SlashCommandBuilder().setName("embed").setDescription("Reusable embed templates")
.addSubcommand(s=>s.setName("create").setDescription("Create/save an embed").addStringOption(o=>o.setName("name").setDescription("Template name").setRequired(true)).addStringOption(o=>o.setName("title").setDescription("Title")).addStringOption(o=>o.setName("description").setDescription("Description")).addStringOption(o=>o.setName("color").setDescription("Hex color, e.g. #ff0000")).addStringOption(o=>o.setName("image").setDescription("Image URL")))
.addSubcommand(s=>s.setName("list").setDescription("List embeds"))
.addSubcommand(s=>s.setName("delete").setDescription("Delete embed").addStringOption(o=>o.setName("name").setDescription("Name").setRequired(true)))
.addSubcommand(s=>s.setName("send").setDescription("Send embed").addStringOption(o=>o.setName("name").setDescription("Name").setRequired(true))),
async execute(i){
 if(!canManage(i))return i.reply({content:"❌ Manage Server required.",ephemeral:true});
 const g=db.guild(i.guild.id),s=i.options.getSubcommand(),name=i.options.getString("name");
 if(s==="create"){g.embeds[name]={title:i.options.getString("title"),description:i.options.getString("description"),color:i.options.getString("color"),image:i.options.getString("image")};db.save();return i.reply(`💾 Saved embed **${name}**.`);}
 if(s==="list")return i.reply(Object.keys(g.embeds).join("\n")||"No saved embeds.");
 if(s==="delete"){delete g.embeds[name];db.save();return i.reply(`🗑️ Deleted **${name}**.`);}
 const x=g.embeds[name];if(!x)return i.reply("❌ Embed not found.");
 const e=new EmbedBuilder();if(x.title)e.setTitle(x.title);if(x.description)e.setDescription(x.description);if(x.color)try{e.setColor(x.color)}catch{}if(x.image)e.setImage(x.image);return i.reply({embeds:[e]});
}};