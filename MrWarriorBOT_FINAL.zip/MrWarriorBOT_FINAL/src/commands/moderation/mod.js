const {SlashCommandBuilder,PermissionFlagsBits}=require("discord.js");
module.exports={data:new SlashCommandBuilder().setName("mod").setDescription("Moderation actions")
.addSubcommand(s=>s.setName("ban").setDescription("Ban").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
.addSubcommand(s=>s.setName("kick").setDescription("Kick").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
.addSubcommand(s=>s.setName("timeout").setDescription("Timeout").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addIntegerOption(o=>o.setName("minutes").setDescription("Minutes").setRequired(true)))
.addSubcommand(s=>s.setName("warn").setDescription("Warn").addUserOption(o=>o.setName("user").setDescription("User").setRequired(true)).addStringOption(o=>o.setName("reason").setDescription("Reason")))
.addSubcommand(s=>s.setName("clear").setDescription("Delete messages").addIntegerOption(o=>o.setName("amount").setDescription("1-100").setRequired(true))),
async execute(i){
 if(!i.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)&&!i.memberPermissions?.has(PermissionFlagsBits.BanMembers)&&!i.memberPermissions?.has(PermissionFlagsBits.ManageMessages))return i.reply({content:"❌ Missing moderation permission.",ephemeral:true});
 const s=i.options.getSubcommand(),u=i.options.getUser("user"),reason=i.options.getString("reason")||"No reason";
 if(s==="ban"){await i.guild.members.ban(u,{reason});return i.reply(`🔨 Banned **${u.tag}** — ${reason}`);}
 if(s==="kick"){const m=await i.guild.members.fetch(u.id);await m.kick(reason);return i.reply(`👢 Kicked **${u.tag}** — ${reason}`);}
 if(s==="timeout"){const m=await i.guild.members.fetch(u.id);await m.timeout(i.options.getInteger("minutes")*60000,reason);return i.reply(`⏳ Timed out **${u.tag}**.`);}
 if(s==="warn")return i.reply(`⚠️ Warning issued to **${u.tag}** — ${reason}`);
 if(s==="clear"){const n=Math.min(100,Math.max(1,i.options.getInteger("amount")));const msgs=await i.channel.bulkDelete(n,true);return i.reply({content:`🧹 Deleted ${msgs.size} messages.`,ephemeral:true});}
}};