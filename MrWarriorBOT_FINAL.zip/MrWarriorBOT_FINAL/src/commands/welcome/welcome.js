const {SlashCommandBuilder,ChannelType}=require("discord.js");const db=require("../../database/db");const {canManage}=require("../../utils/permissions");
function cmd(name,desc,key){
 return {data:new SlashCommandBuilder().setName(name).setDescription(desc)
 .addSubcommand(s=>s.setName("add").setDescription("Add channel message").addChannelOption(o=>o.setName("channel").setDescription("Channel").addChannelTypes(ChannelType.GuildText).setRequired(true)).addStringOption(o=>o.setName("message").setDescription("Message").setRequired(true)))
 .addSubcommand(s=>s.setName("list").setDescription("List configurations"))
 .addSubcommand(s=>s.setName("remove").setDescription("Remove channel config").addChannelOption(o=>o.setName("channel").setDescription("Channel").setRequired(true)))
 .addSubcommand(s=>s.setName("enable").setDescription("Enable").addChannelOption(o=>o.setName("channel").setDescription("Channel").setRequired(true)))
 .addSubcommand(s=>s.setName("disable").setDescription("Disable").addChannelOption(o=>o.setName("channel").setDescription("Channel").setRequired(true))),
 async execute(i){
  if(!canManage(i))return i.reply({content:"❌ Manage Server required.",ephemeral:true});
  const g=db.guild(i.guild.id),s=i.options.getSubcommand(),c=i.options.getChannel("channel");
  if(s==="add"){g[key].enabled=true;g[key].entries.push({channelId:c.id,message:i.options.getString("message"),enabled:true,useContent:true});db.save();return i.reply(`✅ Added ${key} message for ${c}.`);}
  if(s==="list")return i.reply(g[key].entries.map((e,n)=>`${n+1}. <#${e.channelId}> — ${e.enabled?"ON":"OFF"} — ${e.message}`).join("\n")||"None.");
  const e=g[key].entries.find(x=>x.channelId===c.id);if(!e)return i.reply("❌ No configuration for that channel.");
  if(s==="remove"){g[key].entries=g[key].entries.filter(x=>x.channelId!==c.id);db.save();return i.reply("🗑️ Removed.");}
  e.enabled=s==="enable";db.save();return i.reply(`${e.enabled?"✅ Enabled":"⛔ Disabled"} for ${c}.`);
 }};
}
module.exports=cmd("welcome","Welcome message manager","welcome");
