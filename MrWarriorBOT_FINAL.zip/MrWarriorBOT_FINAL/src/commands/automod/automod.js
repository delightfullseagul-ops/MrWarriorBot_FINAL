const {SlashCommandBuilder}=require("discord.js");const db=require("../../database/db");const {canManage}=require("../../utils/permissions");
module.exports={data:new SlashCommandBuilder().setName("automod").setDescription("AutoMod configuration")
.addSubcommand(s=>s.setName("enable").setDescription("Enable"))
.addSubcommand(s=>s.setName("disable").setDescription("Disable"))
.addSubcommand(s=>s.setName("status").setDescription("Status"))
.addSubcommand(s=>s.setName("links").setDescription("Toggle links").addBooleanOption(o=>o.setName("enabled").setDescription("Enabled").setRequired(true)))
.addSubcommand(s=>s.setName("invites").setDescription("Toggle invites").addBooleanOption(o=>o.setName("enabled").setDescription("Enabled").setRequired(true)))
.addSubcommand(s=>s.setName("caps").setDescription("Toggle caps").addBooleanOption(o=>o.setName("enabled").setDescription("Enabled").setRequired(true))),
async execute(i){if(!canManage(i))return i.reply({content:"❌ Manage Server required.",ephemeral:true});const g=db.guild(i.guild.id),s=i.options.getSubcommand();if(s==="enable")g.automod.enabled=true;if(s==="disable")g.automod.enabled=false;if(["links","invites","caps"].includes(s))g.automod[s]=i.options.getBoolean("enabled");db.save();return i.reply(`🤖 AutoMod: **${g.automod.enabled?"ON":"OFF"}**\nLinks: ${g.automod.links}\nInvites: ${g.automod.invites}\nCaps: ${g.automod.caps}`);}};