require("dotenv").config();
const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

const commands = [];
const base = path.join(__dirname, "..", "src", "commands");

function walk(dir) {
  for (const item of fs.readdirSync(dir, {withFileTypes:true})) {
    const p = path.join(dir, item.name);
    if (item.isDirectory()) walk(p);
    else if (item.name.endsWith(".js")) {
      const c = require(p);
      if (c.data?.toJSON) commands.push(c.data.toJSON());
    }
  }
}
walk(base);

(async()=>{
  const rest = new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), {body: commands});
  console.log(`Synced ${commands.length} global commands.`);
})().catch(console.error);
